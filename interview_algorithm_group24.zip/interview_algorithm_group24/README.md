CS 2104 Git and Algorithms Classwork

Group 24

Members: red24, niharsatasia

Problem Number 4, https://www.geeksforgeeks.org/euclidean-algorithms-basic-and-extended/
