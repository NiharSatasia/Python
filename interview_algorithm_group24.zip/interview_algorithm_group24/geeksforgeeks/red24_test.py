'''
Created on Feb2 26, 2021
@author: Red Williams (red24)
@attention: this is a template'''

import unittest
from algorithm import gcdExtended


class AlgorithmTest(unittest.TestCase):    
    def test(self):        
        #declare needed variables for testing            
        #assert statements        
        self.assertEqual(gcdExtended(35, 15), (5, 1, -2))
        self.assertEqual(gcdExtended(0, 0), (0, 0, 1))
        self.assertEqual(gcdExtended(13, 7), (1, -1, 2))
        
    if __name__ == "__main__":    
        import sys;sys.argv = ['', 'Test.AlgorithmTest']    
        unittest.main()