'''
Created on Feb2 26, 2021
@author: Nihar Satasia (niharsatasia)
@attention: this is a template'''
import unittest
from algorithm import gcdExtended


class AlgorithmTest(unittest.TestCase):    
    def test(self):        
        #declare needed variables for testing            
        #assert statements        
        self.assertEqual(gcdExtended(54, 9), (9, 0, 1))
        self.assertEqual(gcdExtended(-64, -16), (-16, 0, 1))
        self.assertEqual(gcdExtended(17, 53), (1, 25, -8))
        
    if __name__ == "__main__":    
        import sys;sys.argv = ['', 'Test.AlgorithmTest']    
        unittest.main()